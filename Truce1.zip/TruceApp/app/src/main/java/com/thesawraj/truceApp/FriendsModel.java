package com.thesawraj.truceApp;

public class FriendsModel {
    int Profile;

    public FriendsModel(int profile) {
        Profile = profile;
    }

    public int getProfile() {
        return Profile;
    }

    public void setProfile(int profile) {
        Profile = profile;
    }
}
