package com.thesawraj.truceApp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;


public class HomeFragment extends Fragment {

    RecyclerView storyRV, dashboardRV;
    ArrayList<StoryModel> storyList;
    ArrayList<DashboardModel> dashboardList;
    ImageView addStory;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //Story Recycler View


        //Dashboard Recycler View
        dashboardRV = view.findViewById(R.id.dashboardRV);
        dashboardList = new ArrayList<>();
        dashboardList.add(new DashboardModel(R.drawable.hipster,R.drawable.new_hope,"New Hope","Traveler, life Lover","247","57","33"));
        dashboardList.add(new DashboardModel(R.drawable.dennis,R.drawable.dennis_kane,"Dennis Kane","Photographer","247","57","33"));
        dashboardList.add(new DashboardModel(R.drawable.nature1,R.drawable.nature,"Alicia ","Traveler, life Lover","247","57","33"));
        dashboardList.add(new DashboardModel(R.drawable.art,R.drawable.nature_dordogne,"Manu ","Traveler, life Lover","247","57","33"));
        DashboardAdapter dashboardAdapter = new DashboardAdapter(dashboardList,getContext());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        dashboardRV.setLayoutManager(linearLayoutManager);
        dashboardRV.addItemDecoration(new DividerItemDecoration(dashboardRV.getContext(), DividerItemDecoration.VERTICAL));
        dashboardRV.setNestedScrollingEnabled(false);
        dashboardRV.setAdapter(dashboardAdapter);



        return view;
    }
}