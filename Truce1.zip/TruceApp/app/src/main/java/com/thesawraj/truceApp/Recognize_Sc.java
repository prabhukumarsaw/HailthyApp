package com.thesawraj.truceApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Recognize_Sc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recognize_sc);
    }

    public void AI_BTN(View v){
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        startActivity(intent);
    }

    public void Smile_BTN(View v){
        Toast.makeText(getBaseContext(), "Main!" , Toast.LENGTH_SHORT ).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
   }