package com.thesawraj.truceApp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.thesawraj.truceApp.databinding.ActivityLoginScBinding;
import com.thesawraj.truceApp.databinding.ActivityRegistationScBinding;

public class Login_sc extends AppCompatActivity {

    ActivityLoginScBinding binding;
    FirebaseAuth auth;
    FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginScBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        auth = FirebaseAuth.getInstance();
        currentUser = auth.getCurrentUser();

        binding.loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.emailET.getText().toString(), passowrd = binding.passwordET.getText().toString();
                auth.signInWithEmailAndPassword(email, passowrd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Intent intent = new Intent(Login_sc.this, Recognize_Sc.class);
                            startActivity(intent);
                        }
                    }
                });

            }
        });

        binding.goToSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_sc.this, Registation_sc.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(currentUser!=null){
            Intent intent = new Intent(Login_sc.this, Recognize_Sc.class);
            startActivity(intent);
        }
    }

    public void letSkip(View v){
        Toast.makeText(getBaseContext(), "AI!" , Toast.LENGTH_SHORT ).show();
        Intent intent = new Intent(this, Recognize_Sc.class);
        startActivity(intent);
    }



}